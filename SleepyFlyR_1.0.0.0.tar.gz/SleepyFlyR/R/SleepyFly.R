#' SleepyFly
#'
#' This function analyzes DAM data for sleep and activity analysis of Drosophila.
#'
#' @param Monitor_File_Directory Text
#' @param Output_Folder_Directory Text
#' @param File_Name Text
#' @param Light_On Text (HH:MM:SS)
#' @param Light_Off Text (HH:MM:SS)
#' @param Start_Date Text (Day Month Year)
#' @param Day_Number Numeric
#' @param Channel_Range Vector
#' @param Sleep_Interval Numeric
#' @param Activity_Interval Numeric
#' @param Minimum_Activity Numeric
#' @param Range Vector
#' @param Config Vector
#' @param DPG_Range Vector
#' @param Sleepgram_Config Vector
#' @param Actogram_Config Vector
#' @param MDA_Range Vector
#' @param MDA_Config Vector
#' @param Control Numeric
#' @param Experiment Vector
#' @param Alt_Config Vector
#'
#' @return Tables (.csv) and figures (.bmp)
#'
#' @examples
#' cat("Please read instructions")
#'
#' @export
#'
#' @importFrom grDevices bmp dev.off
#' @importFrom graphics axis mtext par polygon rect
#' @importFrom stats sd
#' @importFrom utils read.table write.table
SleepyFly<-function(Monitor_File_Directory,Output_Folder_Directory,
                    File_Name,Light_On,Light_Off,Start_Date,Day_Number,Channel_Range,Sleep_Interval,Activity_Interval,Minimum_Activity,
                    Range,Config,
                    DPG_Range,Sleepgram_Config,Actogram_Config,
                    MDA_Range,MDA_Config,
                    Control,Experiment,Alt_Config)
{
  StartTime<-Sys.time()
  Data<-read.table(Monitor_File_Directory)
  setwd(Output_Folder_Directory)
  MonRowNum<-length(Data[,1])
  StartRow<-1
  DayLen<-0
  ZT<-c(0,0)
  if(Light_On=="NA")
  { ZT<-c(Light_Off,2)
  DayLen<-0} else if (Light_Off=="NA")
  { ZT<-c(Light_On,1)
  DayLen<-1440} else {ZT<-c(Light_On,0)}
  while(paste(Data[StartRow,2],Data[StartRow,3],Data[StartRow,4],sep=" ")!=Start_Date)
  { StartRow=StartRow+1
  if(StartRow==MonRowNum) {stop("Day_Start not found")}}
  while(Data[StartRow,5]!=ZT[1])
  { StartRow=StartRow+1
  if(StartRow==MonRowNum) {stop("Incorrect Light_On/Light_Off format")}}
  if(ZT[2]==0)
  { while(Data[StartRow+DayLen,5]!=Light_Off)
  { DayLen=DayLen+1
  if(DayLen==1440) {stop("Incorrect Light_On/Light_Off format")}}}
  MonNum<-floor(((MonRowNum+1-StartRow)/1440))
  ExpNum<-Day_Number
  if(ExpNum>MonNum) {stop("Day_Number exceeds the maximum day of monitor file")}
  Channel<-sort(Channel_Range)
  CNum<-(Channel[2]-Channel[1]+1)
  IndexChannel<-seq(Channel[1],Channel[2],1)
  SInt<-Sleep_Interval
  if(1440%%SInt!=0) {stop("1440 needs to be divisible by Sleep_Interval")}
  SRow<-1440/SInt
  AInt<-Activity_Interval
  if(1440%%AInt!=0) {stop("1440 needs to be divisible by Activity_Interval")}
  ARow<-1440/AInt
  IndexAge<-c(rep(0,CNum))
  IndexLive<-c(rep(1,CNum))
  LogicLive<-c(rep(TRUE,CNum))
  LiveNum<-0
  FName<-File_Name

  RawAData<-as.matrix(Data[StartRow:(StartRow+MonNum*1440-1),(12+Channel[1]):(12+Channel[2])])
  RawSData<-matrix(0,nrow=1440*MonNum,ncol=CNum)
  for(c in 1:CNum) {for(r in 1:(1440*MonNum-4)) {if(sum(RawAData[r:(r+4),c])==0) {RawSData[r:(r+4),c]<-rep(1,5)}}}
  SData<-matrix(0,nrow=1440,ncol=CNum)
  AData<-matrix(0,nrow=1440,ncol=CNum)
  ExpSP<-matrix(0,nrow=ExpNum*SRow,ncol=CNum+3)
  ExpAP<-matrix(0,nrow=ExpNum*ARow,ncol=CNum+3)
  ExpS <-matrix(0,nrow=CNum+3,ncol=ExpNum*3)
  ExpB <-matrix(0,nrow=CNum+3,ncol=ExpNum*3)
  ExpBL<-matrix(0,nrow=CNum+3,ncol=ExpNum*3)
  ExpA <-matrix(0,nrow=CNum+3,ncol=ExpNum*3)
  ExpWA<-matrix(0,nrow=CNum+3,ncol=ExpNum*3)
  ExpL <-matrix(0,nrow=CNum+3,ncol=ExpNum*1)
  ExpAn<-matrix(0,nrow=CNum+3,ncol=ExpNum*2)
  for(Day in 1:ExpNum)
  { D<-(Day-1)*1440
  SData<-RawSData[(1+D):(1440+D),1:CNum]
  AData<-RawAData[(1+D):(1440+D),1:CNum]
  for(r in 1:CNum)
  { for(SR in 1:SRow) {ExpSP[(Day-1)*SRow+SR,r]<-sum(SData[((SR-1)*SInt+1):(SR*SInt),r])}
    for(AR in 1:ARow) {ExpAP[(Day-1)*ARow+AR,r]<-round(mean(AData[((AR-1)*AInt+1):(AR*AInt),r]),2)}
    if(ZT[2]!=2)
    { ExpS[r,Day+ExpNum]=sum(SData[1:DayLen,r])
    for(i in 1:(DayLen-1)) {if(SData[i,r]==0&&SData[i+1,r]==1) {ExpB[r,Day+ExpNum]=ExpB[r,Day+ExpNum]+1}}
    if(ExpS[r,Day+ExpNum]==DayLen) {ExpBL[r,Day+ExpNum]<-DayLen} else if(ExpS[r,Day+ExpNum]==0) {ExpBL[r,Day+ExpNum]<-0}
    else {ExpBL[r,Day+ExpNum]<-round(ExpS[r,Day+ExpNum]/ExpB[r,Day+ExpNum],2)}
    ExpA[r,Day+ExpNum]=sum(AData[1:DayLen,r])
    WMinD<-length(which(AData[1:DayLen,r]!=0))
    if(WMinD==0) {ExpWA[r,Day+ExpNum]<-0} else {ExpWA[r,Day+ExpNum]<-round(ExpA[r,Day+ExpNum]/WMinD,2)}}
    if(ZT[2]!=1)
    { ExpS[r,Day+2*ExpNum]=sum(SData[(DayLen+1):1440,r])
    for(i in (DayLen+1):1439) {if(SData[i,r]==0&&SData[i+1,r]==1) {ExpB[r,Day+2*ExpNum]=ExpB[r,Day+2*ExpNum]+1}}
    if(ExpS[r,Day+2*ExpNum]==(1440-DayLen)) {ExpBL[r,Day+2*ExpNum]<-(1440-DayLen)} else if(ExpS[r,Day+2*ExpNum]==0) {ExpBL[r,Day+2*ExpNum]<-0}
    else {ExpBL[r,Day+2*ExpNum]<-round(ExpS[r,Day+2*ExpNum]/ExpB[r,Day+2*ExpNum],2)}
    ExpA[r,Day+2*ExpNum]=sum(AData[(DayLen+1):1440,r])
    WMinN<-length(which(AData[(DayLen+1):1440,r]!=0))
    if(WMinN==0) {ExpWA[r,Day+2*ExpNum]<-0} else {ExpWA[r,Day+2*ExpNum]<-round(ExpA[r,Day+2*ExpNum]/WMinN,2)}}
    ExpS[r,Day]<-ExpS[r,Day+ExpNum]+ExpS[r,Day+2*ExpNum]
    ExpB[r,Day]<-ExpB[r,Day+ExpNum]+ExpB[r,Day+2*ExpNum]
    if(ExpS[r,Day]==1440) {ExpBL[r,Day]<-1440} else if(ExpS[r,Day]==0) {ExpBL[r,Day]<-0}
    else {ExpBL[r,Day]<-round(ExpS[r,Day]/ExpB[r,Day],2)}
    ExpA[r,Day]<-ExpA[r,Day+ExpNum]+ExpA[r,Day+2*ExpNum]
    WMinFD<-length(which(AData[1:1440,r]!=0))
    if(WMinFD==0) {ExpWA[r,Day]<-0} else {ExpWA[r,Day]<-round(ExpA[r,Day]/WMinFD,2)}
    if(ZT[2]==0)
    { for(i in (DayLen+1):1440) {if(SData[i,r]==0) {ExpL[r,Day]=ExpL[r,Day]+1} else break}
      if(DayLen>359) {ABE<-c(sum(AData[(DayLen-359):DayLen,r]),sum(AData[(DayLen-179):DayLen,r]))
      if(ABE[1]==0) {ExpAn[r,Day]<-0} else {ExpAn[r,Day]<-round(ABE[2]/ABE[1],2)}}
      if(DayLen<1081) {ABM<-c(sum(AData[1081:1440,r]),sum(AData[1261:1440,r]))
      if(ABM[1]==0) {ExpAn[r,Day+ExpNum]<-0} else {ExpAn[r,Day+ExpNum]<-round(ABM[2]/ABM[1],2)}}}
  }}

  for(r in 1:CNum) {for(Day in 1:ExpNum) {if(ExpA[r,Day]>Minimum_Activity) {IndexAge[r]=IndexAge[r]+1} else
  { IndexLive[r]<-0
  LogicLive[r]<-FALSE}}}
  LiveNum<-length(which(IndexLive==1))
  MeanSDSEM<-function(Data,Position)
  { if(Position==1) {Result<-matrix(0,nrow=length(Data[,1]),ncol=3)
  for(i in 1:length(Data[,1]))
  { Result[i,1]<-round(mean(as.numeric(Data[i,LogicLive])),2)
  Result[i,2]<-round(sd(as.numeric(Data[i,LogicLive])),2)
  Result[i,3]<-round(sd(as.numeric(Data[i,LogicLive])/sqrt(LiveNum)),2)}}
    else {Result<-matrix(0,nrow=3,ncol=length(Data[1,]))
    for(i in 1:length(Data[1,]))
    { Result[1,i]<-round(mean(as.numeric(Data[LogicLive,i])),2)
    Result[2,i]<-round(sd(as.numeric(Data[LogicLive,i])),2)
    Result[3,i]<-round(sd(as.numeric(Data[LogicLive,i]))/sqrt(LiveNum),2)}}
    return(Result)}
  ExpSP[,(CNum+1):(CNum+3)]<-MeanSDSEM(ExpSP[,1:CNum],1)
  ExpAP[,(CNum+1):(CNum+3)]<-MeanSDSEM(ExpAP[,1:CNum],1)
  ExpS [(CNum+1):(CNum+3),]<-MeanSDSEM(ExpS [1:CNum,],0)
  ExpB [(CNum+1):(CNum+3),]<-MeanSDSEM(ExpB [1:CNum,],0)
  ExpBL[(CNum+1):(CNum+3),]<-MeanSDSEM(ExpBL[1:CNum,],0)
  ExpA [(CNum+1):(CNum+3),]<-MeanSDSEM(ExpA [1:CNum,],0)
  ExpWA[(CNum+1):(CNum+3),]<-MeanSDSEM(ExpWA[1:CNum,],0)
  ExpL [(CNum+1):(CNum+3),]<-MeanSDSEM(ExpL [1:CNum,],0)
  ExpAn[(CNum+1):(CNum+3),]<-MeanSDSEM(ExpAn[1:CNum,],0)

  RT1<-function(DayNum,Row,Int,Data,LC1)
  { Result<-matrix(" ",nrow=4+DayNum*Row,ncol=4+CNum)
  Result[1:4,]<-rbind(c("Channel",IndexChannel,"Total N",CNum," "),c("Live",IndexLive,"Live n",LiveNum," "),c("Lifespan",IndexAge,"Interval",Int,"min"),c(rep(" ",1+CNum),"Mean","SD","SEM"))
  Result[5:(4+DayNum*Row),1]<-rep(seq(Int,1440,Int),DayNum)
  for(i in 1:DayNum) {Result[(5+(i-1)*Row),1]<-paste(LC1[i],Int,sep=" ")}
  Result[5:(4+DayNum*Row),2:(4+CNum)]<-Data
  return(Result)}
  RT2<-function(DayNum,Data,Range,LR1,LR2,LNum)
  { Result<-matrix(" ",nrow=5+CNum,ncol=3+DayNum*LNum)
  Result[2:(5+CNum),1:3]<-cbind(c("Channel",IndexChannel,"Total N","Live n"," "),c("Live",IndexLive,CNum,LiveNum," "),c("Lifespan",IndexAge,"Mean","SD","SEM"))
  Result[1:2,4:(3+DayNum*LNum)]<-rbind(LR1,LR2)
  for(i in 1:LNum) {Result[3:(5+CNum),(4+(i-1)*DayNum):(3+i*DayNum)]<-Data[,(Range[1]+(i-1)*ExpNum):(Range[2]+(i-1)*ExpNum)]}
  return(Result)}
  FNameT<-paste("[",File_Name,"][C",Channel[1],"-",Channel[2],"]",sep="")

  if(min(Range)>0) {SA<-sort(Range)
  if(length(SA)!=2) {stop("Enter only two numbers in Range")}
  if(max(SA)>ExpNum) {stop("Range exceeds Day_Number")}
  SANum<-SA[2]-SA[1]+1
  IndexSA<-seq(SA[1],SA[2],1)
  SAName<-paste(FNameT,"[D",SA[1],"-",SA[2],"] SA-",sep="")
  SAC<-Config
  if(SAC[1]==1) {SASP<-RT1(SANum,SRow,SInt,ExpSP[((SA[1]-1)*SRow+1):(SA[2]*SRow),],paste(rep("[Day ",SANum),IndexSA,rep("]",SANum),sep=""))
  write.table(SASP,file=paste(SAName,"1-Sleep Profile [Interval=",SInt,"min].csv",sep=""),row.names=FALSE,col.names=FALSE,sep=",")}
  if(SAC[2]==1) {SAAP<-RT1(SANum,ARow,AInt,ExpAP[((SA[1]-1)*ARow+1):(SA[2]*ARow),],paste(rep("[Day ",SANum),IndexSA,rep("]",SANum),sep=""))
  write.table(SAAP,file=paste(SAName,"2-Activity Profile [Interval=",AInt,"min].csv",sep=""),row.names=FALSE,col.names=FALSE,sep=",")}
  if(SAC[3]==1) {SAS <-RT2(SANum,ExpS,SA,c("Full-day",rep(" ",SANum-1),"Day",rep(" ",SANum-1),"Night",rep(" ",SANum-1)),rep(paste(rep("Day ",SANum),IndexSA,sep=""),3),3)
  write.table(SAS ,file=paste(SAName,"3-Sleep.csv",sep=""),row.names=FALSE,col.names=FALSE,sep=",")}
  if(SAC[4]==1) {SAB <-RT2(SANum,ExpB,SA,c("Full-day",rep(" ",SANum-1),"Day",rep(" ",SANum-1),"Night",rep(" ",SANum-1)),rep(paste(rep("Day ",SANum),IndexSA,sep=""),3),3)
  write.table(SAB ,file=paste(SAName,"4-Bout.csv",sep=""),row.names=FALSE,col.names=FALSE,sep=",")}
  if(SAC[5]==1) {SABL<-RT2(SANum,ExpBL,SA,c("Full-day",rep(" ",SANum-1),"Day",rep(" ",SANum-1),"Night",rep(" ",SANum-1)),rep(paste(rep("Day ",SANum),IndexSA,sep=""),3),3)
  write.table(SABL,file=paste(SAName,"5-Bout Length.csv",sep=""),row.names=FALSE,col.names=FALSE,sep=",")}
  if(SAC[6]==1) {SAA <-RT2(SANum,ExpA,SA,c("Full-day",rep(" ",SANum-1),"Day",rep(" ",SANum-1),"Night",rep(" ",SANum-1)),rep(paste(rep("Day ",SANum),IndexSA,sep=""),3),3)
  write.table(SAA ,file=paste(SAName,"6-Activity.csv",sep=""),row.names=FALSE,col.names=FALSE,sep=",")}
  if(SAC[7]==1) {SAWA<-RT2(SANum,ExpWA,SA,c("Full-day",rep(" ",SANum-1),"Day",rep(" ",SANum-1),"Night",rep(" ",SANum-1)),rep(paste(rep("Day ",SANum),IndexSA,sep=""),3),3)
  write.table(SAWA,file=paste(SAName,"7-Waking Activity.csv",sep=""),row.names=FALSE,col.names=FALSE,sep=",")}
  if(SAC[8]==1) {SAL <-RT2(SANum,ExpL,SA,c("Light Off",rep(" ",SANum-1)),paste(rep("Day ",SANum),IndexSA,sep=""),1)
  write.table(SAL ,file=paste(SAName,"8-Latency.csv",sep=""),row.names=FALSE,col.names=FALSE,sep=",")}
  if(SAC[9]==1) {SAAn<-RT2(SANum,ExpAn,SA,c("Evening",rep(" ",SANum-1),"Morning",rep(" ",SANum-1)),rep(paste(rep("Day ",SANum),IndexSA,sep=""),2),2)
  write.table(SAAn,file=paste(SAName,"9-Anticipation.csv",sep=""),row.names=FALSE,col.names=FALSE,sep=",") }
  } else if(min(Range)<0) {stop("Enter 0 or positive integer in Range")}

  if(min(DPG_Range)>0) {DPG<-sort(DPG_Range)
  if(length(DPG)!=2) {stop("Enter only two numbers in DPG_Range")}
  if(max(DPG)>ExpNum) {stop("DPG_Range exceeds Day_Number")}
  DPGNum<-DPG[2]-DPG[1]+1
  IndexDPG<-seq(DPG[1],DPG[2],1)
  DPSGC<-Sleepgram_Config
  DPAGC<-Actogram_Config
  DPSGName<-paste("] DPG-1-Sleepgram [Interval=",SInt,"min][Y Max=",DPSGC[3],"].bmp",sep="")
  DPAGName<-paste("] DPG-2-Actogram [Interval=",AInt,"min][Y Max=",DPAGC[3],"].bmp",sep="")
  DPGram<-function(Data,Row,Int,YMax,Name)
  { bmp(Name,width=2400,height=240*DPGNum)
    par(mfrow=c(DPGNum,1),mai=c(0.025,0.1,0.025,0.1))
    for(i in 1:(DPGNum-1)) {plot(x=0,y=0,xlim=c(0,48),ylim=c(0,YMax),col="black",xaxt="n",yaxt="n",bty="n",type="n")
      for(c in 1:(2*Row)) {rect((c-1)*(Int/60),0,c*(Int/60),Data[(i-1)*Row+c],border=NA,col="black")}
      mtext(text=IndexDPG[i],side=1,adj=0,cex=4,line=-2)
      mtext(text=IndexDPG[i+1],side=1,adj=1,cex=4,line=-2)
      if(i!=DPGNum-1) {LableX<-rep("",5)} else {LableX<-seq(0,48,12)}
      axis(side=1,at=seq(0,48,12),labels=LableX,pos=c(0,0),lwd=4,tck=0,cex.axis=6,padj=1.2)}
    plot(x=0,y=0,xlim=c(0,48),ylim=c(0,YMax),col="black",xaxt="n",yaxt="n",bty="n",type="n")
    for(r in 1:2)
    { rect((r-1)*24+0,YMax/2,(r-1)*24+24*DayLen/1440,YMax/2+YMax/5,col=NA,border="black",lwd=4)
      rect((r-1)*24+24*DayLen/1440,YMax/2,(r-1)*24+24,YMax/2+YMax/5,col="black",border="black",lwd=4)}
    dev.off()}
  if(DPSGC[1]==1) {if(DPSGC[3]%%5!=0) {stop("Y Max of double-plotted sleepgram needs to be divisible by 5")}
    if(DPSGC[2]==0) {DPGram(ExpSP[((DPG[1]-1)*SRow+1):(DPG[2]*SRow),CNum+1],SRow,SInt,DPSGC[3],paste("[",FName,"][C",Channel[1],"-",Channel[2],"][D",DPG[1],"-",DPG[2],DPSGName,sep=""))}
    else {DPGram(ExpSP[((DPG[1]-1)*SRow+1):(DPG[2]*SRow),DPSGC[2]],SRow,SInt,DPSGC[3],paste("[",FName,"][C",DPSGC[2],"][D",DPG[1],"-",DPG[2],DPSGName,sep=""))}}
  if(DPAGC[1]==1) {if(DPAGC[3]%%1!=0) {stop("Y Max of double-plotted actogram needs to be divisible by 1")}
    if(DPAGC[2]==0) {DPGram(ExpAP[((DPG[1]-1)*ARow+1):(DPG[2]*ARow),CNum+1],ARow,AInt,DPAGC[3],paste("[",FName,"][C",Channel[1],"-",Channel[2],"][D",DPG[1],"-",DPG[2],DPAGName,sep=""))}
    else {DPGram(ExpAP[((DPG[1]-1)*ARow+1):(DPG[2]*ARow),DPAGC[2]],ARow,AInt,DPAGC[3],paste("[",FName,"][C",DPAGC[2],"][D",DPG[1],"-",DPG[2],DPAGName,sep=""))}}
  } else if(min(DPG_Range)<0) {stop("Enter 0 or positive integer in DPG_Range")}

  if(min(MDA_Range)>0) {MDA<-sort(MDA_Range)
  if(length(MDA)!=2) {stop("Enter only two numbers in MDA_Range")}
  if(max(MDA)>ExpNum) {stop("MDA_Range exceeds MDA_Number")}
  MDANum<-MDA[2]-MDA[1]+1
  MDAC<-MDA_Config
  MDAName<-paste(FNameT,"[D",MDA[1],"-",MDA[2],"] MDA-",sep="")
  if(MDAC[1]==1)
  { MDAB<-RT2(18,matrix(" ",nrow=CNum+3,ncol=18),c(1,18),c("Sleep"," "," ","Bout"," "," ","Bout Length"," "," ","Activity"," "," ","Waking Activity"," "," ","Latency","Anticipation"," "),
              c(rep(c("Full-day","Day","Night"),5),"Light off","Evening","Morning"),1)
  ExpBind<-cbind(ExpS,ExpB,ExpBL,ExpA,ExpWA,ExpL,ExpAn)
  for(r in 1:CNum) {for(i in 1:18) {MDAB[2+r,3+i]<-round(mean(ExpBind[r,((i-1)*ExpNum+MDA[1]):((i-1)*ExpNum+MDA[2])]),2)}}
  MDAB[(CNum+3):(CNum+5),4:21]<-MeanSDSEM(MDAB[3:(2+CNum),4:21],0)
  write.table(MDAB,file=paste(MDAName,"1-Basic.csv",sep=""),row.names=FALSE,col.names=FALSE,sep=",")}
  MDAPMeanSDSEM<-function(Data,Row)
  { Result<-matrix(0,nrow=3*Row,ncol=CNum)
  Index<-seq(0,(MDANum-1)*Row,Row)
  for(c in 1:CNum) {for(i in 1:Row)
  { Result[i,c]<-round(mean(as.numeric(Data[Index+i,c])),2)
  Result[i+Row,c]<-round(sd(as.numeric(Data[Index+i,c])),2)
  Result[i+2*Row,c]<-round(sd(as.numeric(Data[Index+i,c]))/sqrt(MDANum),2)}}
  return(Result)}
  MDAGram<-function(Data,Row,Int,YMax,YTick,Name,YTitle)
  { AxisX<-seq(Int/60,24,Int/60)
  bmp(Name,width=4800,height=1200*ceiling((CNum+1)/4))
  par(mfrow=c(ceiling((CNum+1)/4),4),mai=c(1.8,1.8,1.8,1.8))
  for(i in 1:(CNum+1)) {if(i<=CNum) {Title<-paste("Channel ",IndexChannel[i]," Live=",IndexLive[i],sep="")} else {Title<-"Live Channel Average"}
    plot(x=AxisX,y=Data[1:Row,i],main=Title,xlim=c(0,24),ylim=c(0,YMax),type="l",bty="n",xaxt="n",yaxt="n",cex.main=10,lwd=4,xlab="",ylab="")
    YUp<-as.numeric(Data[1:Row,i])+as.numeric(Data[(2*Row+1):(3*Row),i])
    YDown<-as.numeric(Data[1:Row,i])-as.numeric(Data[(2*Row+1):(3*Row),i])
    polygon(c(AxisX,rev(AxisX)),c(YUp,rev(YDown)),col="grey",density=10,border="grey",lwd=2)
    rect(0,-(YMax/30),24*DayLen/1440,0,col=NA,border="black",lwd=4)
    rect(24*DayLen/1440,-(YMax/30),24,0,col="black",border="black",lwd=4)
    axis(side=1,at=seq(0,24,6),cex.axis=8,pos=c(0,0),lwd=4,padj=1.5,tck=0)
    axis(side=2,at=seq(0,YMax,YTick),cex.axis=8,pos=c(0,0),lwd=4,las=2,hadj=1.2,tck=-0.015)
    mtext(text=YTitle,side=2,adj=0,cex=5,line=8)}
  dev.off()}
  if(MDAC[2]==1) {MDASP<-RT1(3,SRow,SInt,matrix(" ",nrow=3*SRow,ncol=CNum+3),c("[Mean]","[SD]","[SEM]"))
  MDASP[5:(4+3*SRow),2:(1+CNum)]<-MDAPMeanSDSEM(ExpSP[((MDA[1]-1)*SRow+1):(MDA[2]*SRow),1:CNum],SRow)
  MDASP[5:(4+SRow),(2+CNum):(4+CNum)]<-MeanSDSEM(MDASP[5:(4+SRow),2:(1+CNum)],1)
  write.table(MDASP,file=paste(MDAName,"2-Sleep Profile [Interval=",SInt,"min].csv",sep=""),row.names=FALSE,col.names=FALSE,sep=",")
  if(MDAC[3]%%5!=0) {stop("Y Max of MDA sleepgram needs to be divisible by 5")}
  MDASP[(5+SRow):(4+3*SRow),2+CNum]<-c(MDASP[5:(4+SRow),3+CNum],MDASP[5:(4+SRow),4+CNum])
  MDASGName<-paste(MDAName,"3-Sleep Graph [Interval=",SInt,"min][Y Max=",MDAC[3],"].bmp",sep="")
  MDAGram(MDASP[5:(4+3*SRow),2:(2+CNum)],SRow,SInt,MDAC[3],5,MDASGName,paste("            Sleep (min / ",SInt," min)",sep=""))}
  if(MDAC[4]==1) {MDAAP<-RT1(3,ARow,AInt,matrix(" ",nrow=3*ARow,ncol=CNum+3),c("[Mean]","[SD]","[SEM]"))
  MDAAP[5:(4+3*ARow),2:(1+CNum)]<-MDAPMeanSDSEM(ExpAP[((MDA[1]-1)*ARow+1):(MDA[2]*ARow),1:CNum],ARow)
  MDAAP[5:(4+ARow),(2+CNum):(4+CNum)]<-MeanSDSEM(MDAAP[5:(4+ARow),2:(1+CNum)],1)
  write.table(MDAAP,file=paste(MDAName,"4-Activity Profile [Interval=",AInt,"min].csv",sep=""),row.names=FALSE,col.names=FALSE,sep=",")
  if(MDAC[5]%%1!=0) {stop("Y Max of MDA actogram needs to be divisible by 1")}
  MDAAP[(5+ARow):(4+3*ARow),2+CNum]<-c(MDAAP[5:(4+ARow),3+CNum],MDAAP[5:(4+ARow),4+CNum])
  MDAAGName<-paste(MDAName,"5-Activity Graph [Interval=",AInt,"min][Y Max=",MDAC[5],"].bmp",sep="")
  MDAGram(MDAAP[5:(4+3*ARow),2:(2+CNum)],ARow,AInt,MDAC[5],1,MDAAGName,"           Activity (count / min)")}
  } else if(min(MDA_Range)<0) {stop("Enter 0 or positive integer in MDA_Range")}

  if(Control>0) {AltCTL<-Control
  AltEXP<-Experiment
  if(length(AltEXP)==0) {stop("Enter at least one number in Experiment")}
  if(AltCTL>ExpNum|max(AltEXP)>ExpNum|min(AltEXP)<1) {stop("Control or Experiment exceeds Day_Number")}
  AltC<-Alt_Config
  AltNum<-length(AltEXP)
  AltName<-paste(FNameT,"[CTL=",AltCTL,"][EXP=",paste(AltEXP,collapse=","),"] Alt-",sep="")
  if(AltC[1]==1) {AltSP<-RT1(AltNum,SRow,SInt,matrix(" ",nrow=AltNum*SRow,ncol=CNum+3),paste(rep("[D",AltNum),AltEXP,rep(paste("-D",AltCTL,"]",sep=""),AltNum),sep=""))
  for(i in 1:AltNum) {AltSP[((i-1)*SRow+5):(i*SRow+4),2:(1+CNum)]<-ExpSP[((AltEXP[i]-1)*SRow+1):(AltEXP[i]*SRow),1:CNum]-ExpSP[((AltCTL-1)*SRow+1):(AltCTL*SRow),1:CNum]}
  AltSP[5:(4+AltNum*SRow),(2+CNum):(4+CNum)]<-MeanSDSEM(AltSP[5:(4+AltNum*SRow),2:(1+CNum)],1)
  write.table(AltSP,file=paste(AltName,"1-Sleep Profile [Interval=",SInt,"min].csv",sep=""),row.names=FALSE,col.names=FALSE,sep=",")}
  if(AltC[1]==1) {AltAP<-RT1(AltNum,ARow,AInt,matrix(" ",nrow=AltNum*ARow,ncol=CNum+3),paste(rep("[D",AltNum),AltEXP,rep(paste("-D",AltCTL,"]",sep=""),AltNum),sep=""))
  for(i in 1:AltNum) {AltAP[((i-1)*ARow+5):(i*ARow+4),2:(1+CNum)]<-ExpAP[((AltEXP[i]-1)*ARow+1):(AltEXP[i]*ARow),1:CNum]-ExpAP[((AltCTL-1)*ARow+1):(AltCTL*ARow),1:CNum]}
  AltAP[5:(4+AltNum*ARow),(2+CNum):(4+CNum)]<-MeanSDSEM(AltAP[5:(4+AltNum*ARow),2:(1+CNum)],1)
  write.table(AltAP,file=paste(AltName,"2-Activity Profile [Interval=",AInt,"min].csv",sep=""),row.names=FALSE,col.names=FALSE,sep=",")}
  AltBind<-cbind(ExpS,ExpB,ExpA,ExpL)
  AltData<-matrix(0,nrow=CNum+3,ncol=10*(AltNum+1))
  for(i in 1:10) {AltData[1:CNum,((i-1)*(AltNum+1)+1)]<-AltBind[1:CNum,((i-1)*ExpNum+AltCTL)]
  for(a in 1:AltNum) {AltData[1:CNum,((i-1)*(AltNum+1)+1+a)]<-AltBind[1:CNum,((i-1)*ExpNum+AltEXP[a])]-AltBind[1:CNum,((i-1)*ExpNum+AltCTL)]}}
  AltData[(CNum+1):(CNum+3),]<-MeanSDSEM(AltData[1:CNum,],0)
  AltLR2<-c(paste("D",AltCTL,sep=""),paste(rep("D",AltNum),AltEXP,rep(paste("-D",AltCTL,sep=""),AltNum),sep=""))
  if(AltC[3]==1) {AltS<-RT2(3*(AltNum+1),AltData[,1:(3*(AltNum+1))],c(1,3*(AltNum+1)),c("Full-day",rep(" ",AltNum),"Day",rep(" ",AltNum),"Night",rep(" ",AltNum)),rep(AltLR2,3),1)
  write.table(AltS,file=paste(AltName,"3-Sleep.csv",sep=""),row.names=FALSE,col.names=FALSE,sep=",")}
  if(AltC[4]==1) {AltB<-RT2(3*(AltNum+1),AltData[,(3*(AltNum+1)+1):(6*(AltNum+1))],c(1,3*(AltNum+1)),c("Full-day",rep(" ",AltNum),"Day",rep(" ",AltNum),"Night",rep(" ",AltNum)),rep(AltLR2,3),1)
  write.table(AltB,file=paste(AltName,"4-Bout.csv",sep=""),row.names=FALSE,col.names=FALSE,sep=",")}
  if(AltC[5]==1) {AltA<-RT2(3*(AltNum+1),AltData[,(6*(AltNum+1)+1):(9*(AltNum+1))],c(1,3*(AltNum+1)),c("Full-day",rep(" ",AltNum),"Day",rep(" ",AltNum),"Night",rep(" ",AltNum)),rep(AltLR2,3),1)
  write.table(AltA,file=paste(AltName,"5-Activity.csv",sep=""),row.names=FALSE,col.names=FALSE,sep=",")}
  if(AltC[6]==1) {AltL<-RT2(AltNum+1,AltData[,(9*(AltNum+1)+1):(10*(AltNum+1))],c(1,AltNum+1),c("Light Off",rep(" ",AltNum)),AltLR2,1)
  write.table(AltL,file=paste(AltName,"6-Latency.csv",sep=""),row.names=FALSE,col.names=FALSE,sep=",")}
  } else if(Control<0) {stop("Enter 0 or positive integer in Control")}
  EndTime<-Sys.time()
  cat("Analysis Finished! Running Time=",EndTime-StartTime," sec",sep="")
}
